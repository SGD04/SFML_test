#include <SFML/Graphics.hpp>
#include <iostream>

using namespace std;

int main()
{
    int x=0;
    int y=0;

    // Declare and create a new window
    sf::RenderWindow window(sf::VideoMode(800, 600), "Ghost Warrior",sf::Style::Default);

    window.setVerticalSyncEnabled(true);    // activate vertical synchronization

    sf::RectangleShape shape(sf::Vector2f(80, 110));
	shape.setFillColor(sf::Color::Green);


	sf::Texture Background;
    if (!Background.loadFromFile("fond_ville_nuit.png"))
    {
    // error...
        cout<<"erreur chargement texture"<<endl;
    }

    sf::Texture Ghost;
    if (!Ghost.loadFromFile("ghost.png"))
    {
    // error...
        cout<<"erreur chargement texture"<<endl;
    }
    sf::Texture Robot;
    if (!Robot.loadFromFile("robot.jpg"))
    {
    // error...
        cout<<"erreur chargement texture"<<endl;
    }

    sf::Sprite ghost;
    ghost.setTexture(Ghost);
    ghost.setScale(0.15f,0.15f);
    ghost.setPosition(0,0);

    sf::Sprite robot;
    robot.setTexture(Robot);
    robot.setScale(0.3f,0.3f);
    robot.setPosition(100,0);

    sf::Sprite background;
    background.setTexture(Background);
    background.scale(2.3f,3.2f);


// run the program as long as the window is open
    while (window.isOpen())
    {
        // check all the window's events that were triggered since the last iteration of the loop
        sf::Event event;
        while (window.pollEvent(event))
        {
            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed)
                window.close();
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
                {
                    x=x-1;
                    cout<<x<<endl;
                    ghost.move(-10,0);
                }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
                {
                    x=x+1;
                    cout<<x<<endl;
                    ghost.move(10,0);
                }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
                {
                    y=y-1;
                    cout<<x<<endl;
                    ghost.move(0,-10);
                }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
                {
                    y=y+1;
                    cout<<x<<endl;
                    ghost.move(0,10);
                }
        window.clear();
        window.draw(background);
        window.draw(robot);
		window.draw(ghost);
		window.display();
        }
    }

    return 0;
}
